import logo from './logo.svg';
import './App.css';
import Quiz from './features/quiz/quiz';

function App() {
  return (
    <Quiz />
  );
}

export default App;
