//// https://opentdb.com/api.php?amount=15
export const BASEURL="https://opentdb.com/"
export const GETQUESTION=BASEURL+"/api.php?amount="