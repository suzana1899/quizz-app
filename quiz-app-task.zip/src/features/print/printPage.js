 const PrintableComponent = () => {
  const handlePrint = () => {
    window.print();
  };
};
